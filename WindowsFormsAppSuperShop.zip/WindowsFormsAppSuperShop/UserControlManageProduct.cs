﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using WFADBG;

namespace WindowsFormsAppSuperShop
{
     
    public partial class UserControlManageProduct : UserControl
    {
        private DataAccess Da { get; set; }
        public UserControlManageProduct()
        {
            InitializeComponent();
            this.Da = new DataAccess();
            this.PopulatedGridView();
        }
        public void PopulatedGridView(string sql = "Select * from ProductInfo;")
        {
            var ds = this.Da.ExecuteQuery(sql);
            this.dgvProductInfo.DataSource = ds.Tables[0];
        }

        private void pnlBackground_Paint(object sender, PaintEventArgs e)
        {

        }

        private void btnAddMember_Click(object sender, EventArgs e)
        {
            FormAddProduct fap  = new FormAddProduct();
            fap.Show();
            this.Show();

        }

        private void txtSearch_TextChanged(object sender, EventArgs e)
        {
            string sql = @"select * from ProductInfo where ProductID = '" + this.txtSearch.Text + "';";
            this.PopulatedGridView(sql);
        }

        private void btnRefresh_Click(object sender, EventArgs e)
        {
            this.PopulatedGridView();
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            try
            {
                if (this.dgvProductInfo.SelectedRows.Count < 1)
                {
                    MessageBox.Show("Please select a row first to remove the data", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                    return;
                }

                DialogResult result = MessageBox.Show("Are you sure to remove this Product?", "Alert", MessageBoxButtons.YesNo, MessageBoxIcon.Exclamation);
                if (result == DialogResult.No)
                    return;

                var ProductID = this.dgvProductInfo.CurrentRow.Cells[0].Value.ToString();
                var ProductName = this.dgvProductInfo.CurrentRow.Cells["ProductName"].Value.ToString();
                var query = "delete from ProductInfo where ProductID = '" + ProductID + "';";
                var count = this.Da.ExecuteDMLQuery(query);

                if (count == 1)
                    MessageBox.Show(ProductName.ToUpper() + " has been removed from the list.");
                else
                    MessageBox.Show("Remove failed");

                this.PopulatedGridView();
                
            }
            catch (Exception exc)
            {
                MessageBox.Show("Error has occured:\n" + exc.Message);
            }
        }
    }
}
