﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using WFADBG;

namespace WindowsFormsAppSuperShop
{
    public partial class FormAddCart : Form
    {
      
        private DataAccess Da { get; set; }
        
        public FormAddCart()
        {
            InitializeComponent();
            this.Da = new DataAccess();
            this.PopulatedGridView();
        }
/*
        public FormAddCart(string text, FormUserHome fum):this()
        {
            this.txtUserID.Text = text; 
            this.Fum = fum;
        }

        */

        public void PopulatedGridView(string sql = "Select * from sellsInfo;")
        {
            var ds = this.Da.ExecuteQuery(sql);
            this.dgvCart.DataSource = ds.Tables[0];
        }

        private void Cart_Load(object sender, EventArgs e)
        {
            this.dgvCart.ClearSelection();
        }

        private void btnRemove_Click(object sender, EventArgs e)
        {
            try
            {
                
                if (this.dgvCart.SelectedRows.Count < 1)
                {
                    MessageBox.Show("Please select a row first to remove the data", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                    return;
                }

                DialogResult result = MessageBox.Show("Are you sure to remove this Iteam?", "Alert", MessageBoxButtons.YesNo, MessageBoxIcon.Exclamation);
                if (result == DialogResult.No)
                    return;

                var ProductID = this.dgvCart.CurrentRow.Cells[0].Value.ToString();
                var ProductName = this.dgvCart.CurrentRow.Cells["ProductName"].Value.ToString();
                var query = "delete from sellsInfo where ProductID = '" + ProductID + "';";
                var count = this.Da.ExecuteDMLQuery(query);

                if (count == 1)
                    MessageBox.Show(ProductName.ToUpper() + " has been removed from the list.");
                else
                    MessageBox.Show("Remove failed");

                this.PopulatedGridView();
                
            }
            catch (Exception exc)
            {
                MessageBox.Show("Error has occured:\n" + exc.Message);
            }
        }

        private void dgvCart_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
        }


        


        private void btnConfirm_Click(object sender, EventArgs e)
        {
            try
            {
                string query = null;
                var sql = "DELETE FROM SellsInfo;";
                var ds = this.Da.ExecuteQuery(sql);


                var ID = this.dgvCart.CurrentRow.Cells["UserID"].Value.ToString();
                var PID = this.dgvCart.CurrentRow.Cells["ProductID"].Value.ToString();
                var Amount = this.dgvCart.CurrentRow.Cells["ProductTotalPrice"].Value.ToString();
                var CID = this.txtCustomerID.Text.ToString();


                query = @"insert into  money values('" + ID + "','" + PID + "','" + Amount + "','" + CID + "');";
                var count = this.Da.ExecuteDMLQuery(query);

                FormConfirm fm = new FormConfirm();
                this.Hide();
                fm.Show();
            }
            catch { }

        }
    }
}
