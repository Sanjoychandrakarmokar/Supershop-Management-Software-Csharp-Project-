﻿
namespace projectcs
{
    partial class UserControlManagerDashboard
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.palBackground = new System.Windows.Forms.Panel();
            this.pnlManagerprofile = new System.Windows.Forms.Panel();
            this.lblManager = new System.Windows.Forms.Label();
            this.lblJoiningDate = new System.Windows.Forms.Label();
            this.lblWorkingDetails = new System.Windows.Forms.Label();
            this.pictureBoxManagerpic = new System.Windows.Forms.PictureBox();
            this.lblAboutUser = new System.Windows.Forms.Label();
            this.palBackground.SuspendLayout();
            this.pnlManagerprofile.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxManagerpic)).BeginInit();
            this.SuspendLayout();
            // 
            // palBackground
            // 
            this.palBackground.BackgroundImage = global::WindowsFormsAppSuperShop.Properties.Resources.bkg_blu;
            this.palBackground.Controls.Add(this.pnlManagerprofile);
            this.palBackground.Dock = System.Windows.Forms.DockStyle.Fill;
            this.palBackground.Location = new System.Drawing.Point(0, 0);
            this.palBackground.Margin = new System.Windows.Forms.Padding(2);
            this.palBackground.Name = "palBackground";
            this.palBackground.Size = new System.Drawing.Size(641, 461);
            this.palBackground.TabIndex = 0;
            this.palBackground.Paint += new System.Windows.Forms.PaintEventHandler(this.panel1_Paint);
            // 
            // pnlManagerprofile
            // 
            this.pnlManagerprofile.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.pnlManagerprofile.Controls.Add(this.lblManager);
            this.pnlManagerprofile.Controls.Add(this.lblJoiningDate);
            this.pnlManagerprofile.Controls.Add(this.lblWorkingDetails);
            this.pnlManagerprofile.Controls.Add(this.pictureBoxManagerpic);
            this.pnlManagerprofile.Controls.Add(this.lblAboutUser);
            this.pnlManagerprofile.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlManagerprofile.Location = new System.Drawing.Point(0, 0);
            this.pnlManagerprofile.Margin = new System.Windows.Forms.Padding(2);
            this.pnlManagerprofile.Name = "pnlManagerprofile";
            this.pnlManagerprofile.Size = new System.Drawing.Size(641, 461);
            this.pnlManagerprofile.TabIndex = 0;
            this.pnlManagerprofile.Paint += new System.Windows.Forms.PaintEventHandler(this.pnlManagerprofile_Paint);
            // 
            // lblManager
            // 
            this.lblManager.AutoSize = true;
            this.lblManager.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblManager.Location = new System.Drawing.Point(267, 228);
            this.lblManager.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblManager.Name = "lblManager";
            this.lblManager.Size = new System.Drawing.Size(71, 17);
            this.lblManager.TabIndex = 4;
            this.lblManager.Text = "Manager";
            // 
            // lblJoiningDate
            // 
            this.lblJoiningDate.AutoSize = true;
            this.lblJoiningDate.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblJoiningDate.Location = new System.Drawing.Point(251, 268);
            this.lblJoiningDate.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblJoiningDate.Name = "lblJoiningDate";
            this.lblJoiningDate.Size = new System.Drawing.Size(106, 17);
            this.lblJoiningDate.TabIndex = 3;
            this.lblJoiningDate.Text = "May 10, 2022";
            this.lblJoiningDate.Click += new System.EventHandler(this.label1_Click);
            // 
            // lblWorkingDetails
            // 
            this.lblWorkingDetails.AutoSize = true;
            this.lblWorkingDetails.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblWorkingDetails.Location = new System.Drawing.Point(216, 245);
            this.lblWorkingDetails.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblWorkingDetails.Name = "lblWorkingDetails";
            this.lblWorkingDetails.Size = new System.Drawing.Size(161, 17);
            this.lblWorkingDetails.TabIndex = 2;
            this.lblWorkingDetails.Text = "is working here since";
            this.lblWorkingDetails.Click += new System.EventHandler(this.lblWorkingDetails_Click);
            // 
            // pictureBoxManagerpic
            // 
            this.pictureBoxManagerpic.Image = global::WindowsFormsAppSuperShop.Properties.Resources.businessman_man_person_people_2842;
            this.pictureBoxManagerpic.Location = new System.Drawing.Point(263, 185);
            this.pictureBoxManagerpic.Margin = new System.Windows.Forms.Padding(2);
            this.pictureBoxManagerpic.Name = "pictureBoxManagerpic";
            this.pictureBoxManagerpic.Size = new System.Drawing.Size(75, 41);
            this.pictureBoxManagerpic.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBoxManagerpic.TabIndex = 1;
            this.pictureBoxManagerpic.TabStop = false;
            // 
            // lblAboutUser
            // 
            this.lblAboutUser.AutoSize = true;
            this.lblAboutUser.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAboutUser.Location = new System.Drawing.Point(245, 159);
            this.lblAboutUser.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblAboutUser.Name = "lblAboutUser";
            this.lblAboutUser.Size = new System.Drawing.Size(114, 24);
            this.lblAboutUser.TabIndex = 0;
            this.lblAboutUser.Text = "About User";
            // 
            // UserControlManagerDashboard
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.palBackground);
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "UserControlManagerDashboard";
            this.Size = new System.Drawing.Size(641, 461);
            this.Load += new System.EventHandler(this.UserControlManagerDashboard_Load);
            this.palBackground.ResumeLayout(false);
            this.pnlManagerprofile.ResumeLayout(false);
            this.pnlManagerprofile.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxManagerpic)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel palBackground;
        private System.Windows.Forms.Panel pnlManagerprofile;
        private System.Windows.Forms.Label lblManager;
        private System.Windows.Forms.Label lblJoiningDate;
        private System.Windows.Forms.Label lblWorkingDetails;
        private System.Windows.Forms.PictureBox pictureBoxManagerpic;
        private System.Windows.Forms.Label lblAboutUser;
    }
}
