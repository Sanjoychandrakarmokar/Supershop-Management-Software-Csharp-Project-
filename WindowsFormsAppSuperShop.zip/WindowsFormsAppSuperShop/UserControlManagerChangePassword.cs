﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using WFADBG;

namespace WindowsFormsAppSuperShop
{
    public partial class UserControlManagerChangePassword : UserControl
    {
        private DataAccess Da { get; set; }
        public UserControlManagerChangePassword()
        {
            InitializeComponent();
            this.Da = new DataAccess();

        }
        private void pnlBackground_Paint(object sender, PaintEventArgs e)
        {

        }

        private void cbShowPassword_CheckedChanged(object sender, EventArgs e)
        {
            if(cbShowPassword.Checked)
            {
                txtTypeNewPassword.UseSystemPasswordChar = true;
            }
            else
            {
                txtTypeNewPassword.UseSystemPasswordChar = false;
            }
        }

        private void txtTypeNewPassword_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtConfirmPassword_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnConfirm_Click(object sender, EventArgs e)
        {
            try
            {
                string query = null;
                var sql = "select * from Info where UserID='" + this.txtID.Text + "';";
                var ds = this.Da.ExecuteQuery(sql);

                if (ds.Tables[0].Rows.Count == 1)
                {
                    query = @"update Info set Password = " + txtTypeNewPassword.Text + " where password = " + txtCurrentPassword.Text + "";

                    var count = this.Da.ExecuteDMLQuery(query);

                    if (count == 1)
                        MessageBox.Show("Update Sucessful");
                    else
                        MessageBox.Show("Update failed");
                }

            }
            catch
            {
               MessageBox.Show("Update failed");

            }
            
        }

        private void txtCurrentPassword_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            txtCurrentPassword.Clear();
            txtTypeNewPassword.Clear();
        }
    }
}
