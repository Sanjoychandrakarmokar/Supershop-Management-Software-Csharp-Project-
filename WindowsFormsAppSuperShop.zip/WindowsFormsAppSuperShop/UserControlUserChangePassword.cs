﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using WFADBG;

namespace WindowsFormsAppSuperShop
{
    public partial class UserControlUserChangePassword : UserControl
    {
        private DataAccess Da { get; set; }

        public UserControlUserChangePassword()
        {
            InitializeComponent();
            this.Da = new DataAccess();
        }

    

        private void btnConfirm_Click_1(object sender, EventArgs e)
        {
            try
            {
                string query = null;
                var sql = "select * from Info where UserID='" + this.txtID.Text + "';";
                var ds = this.Da.ExecuteQuery(sql);

                if (ds.Tables[0].Rows.Count == 1)
                {
                    query = @"update Info set Password = " + txtTypeNewPassword.Text + " where password = " + txtCurrentPassword.Text + "";

                    var count = this.Da.ExecuteDMLQuery(query);

                    if (count == 1)
                        MessageBox.Show("Update Sucessful");
                    else
                        MessageBox.Show("Update failed");
                }

            }

            catch
            {
                MessageBox.Show("Update failed");

            }

        }

        private void btnCancel_Click_1(object sender, EventArgs e)
        {
            txtCurrentPassword.Clear();
            txtTypeNewPassword.Clear();
        }

        private void cbShowPassword_CheckedChanged_1(object sender, EventArgs e)
        {
            if (cbShowPassword.Checked)
            {
                txtTypeNewPassword.UseSystemPasswordChar = true;
            }
            else
            {
                txtTypeNewPassword.UseSystemPasswordChar = false;
            }
        }

        private void pnlBackground_Paint(object sender, PaintEventArgs e)
        {

        }
    }
}
