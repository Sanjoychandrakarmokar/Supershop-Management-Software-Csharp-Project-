﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsAppSuperShop
{

    public partial class FormLogin : Form
    {
        
        //public static FormLogin instance;
        public FormLogin()
        {
            InitializeComponent();
          // instance = this;
        }

        private void FormLogin_FormClosed(object sender, FormClosedEventArgs e)
        {
           Application.Exit();
        }

        private void FormLogin_Load(object sender, EventArgs e)
        {

        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            
            SqlConnection  con = new SqlConnection(@"Data Source=DESKTOP-6CCVGDN\SQLEXPRESS;Initial Catalog=DB;Integrated Security=True;Encrypt=False");
            SqlCommand cmd = new SqlCommand("select * from Info where UserID= '" + this.txtUserID.Text + "' and Password='" + this.txtPassword.Text + "'", con);
            // sqlcon.Open();
            // SqlCommand sqlcom = new SqlCommand(sql, sqlcon);
            SqlDataAdapter sda = new SqlDataAdapter(cmd);
            //DataSet ds = new DataSet();
           //sda.Fill(ds);
           DataTable dt = new DataTable(); 
            sda .Fill(dt);
            string cmbIteamValue = cmbUserType.SelectedItem.ToString();



            if (dt.Rows.Count>0)
            {
                for (int i = 0; i < dt.Rows.Count; i++)
                {
                    if (dt.Rows[i]["UserType"].ToString()== cmbIteamValue)
                    {
                        var UserID = dt.Rows[0][0].ToString();
                        MessageBox.Show("Welcome To Apon Supershop" + UserID.ToUpper());

                        
                        if (cmbUserType.SelectedIndex == 0)
                        {
                            FormManagerHome fm = new FormManagerHome(UserID,this);
                            fm.Show();
                            this.Hide();
                        }
                        else
                        {

                            FormUserHome ff = new FormUserHome(UserID, this);
                            ff.Show();
                            this.Hide();    
                        }

                    }
                }

            }
            else
            {
                MessageBox.Show("Error");
            }





        }

        private void pnlRight_Paint(object sender, PaintEventArgs e)
        {

        }

        private void cbshowpassword_CheckedChanged(object sender, EventArgs e)
        {
            if (cbshowpassword.Checked)
            {
                txtPassword.UseSystemPasswordChar = true;
            }
            else
            {
                txtPassword.UseSystemPasswordChar = false;
            }
        }

       /* private void txtUserID_TextChanged(object sender, EventArgs e)
        {
            FormUserHome fm = new FormUserHome();
            fm.Show();
        }*/
    }
}
