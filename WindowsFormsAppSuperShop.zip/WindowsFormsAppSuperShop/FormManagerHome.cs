﻿using projectcs;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using WFADBG;

namespace WindowsFormsAppSuperShop
{
    

    public partial class FormManagerHome : Form
    {
       // private FormLogin fl { get; set; }

        private DataAccess Da {  get; set; }


        UserControlManageMember ucmm=new UserControlManageMember();
        UserControlManageProduct ucmp=new UserControlManageProduct();
        UserControlManagerDashboard ucmd =new UserControlManagerDashboard();
        UserControlManagerChangePassword uccp =new UserControlManagerChangePassword();
        UserControlManagerTransaction uccmt = new UserControlManagerTransaction();

        public FormManagerHome()
        {
            InitializeComponent();
            this.Da = new DataAccess();
        }

        public FormManagerHome(string text, FormLogin f1): this()
        {
           // this.lblOutput.Text += text;
           // this.fl = f1;
        }


        private void btnManageMember_Click(object sender, EventArgs e)
        {
            this.pnlRight.Controls.Add(ucmm);
            ucmm.Visible = true;
            ucmp.Visible = false;
            ucmd.Visible = false;
            uccp.Visible = false;
            uccmt.Visible = false;
        }

        private void FormManagerHome_FormClosed(object sender, FormClosedEventArgs e)
        {
            Application.Exit();
        }


        private void btnManageProduct_Click(object sender, EventArgs e)
        {
            this.pnlRight.Controls.Add(ucmp);
            ucmp.Visible = true;
            ucmm.Visible = false;
            ucmd.Visible = false;
            uccp.Visible = false;
            uccmt.Visible = false;


        }

        private void FormManagerHome_Load(object sender, EventArgs e)
        {
            this.pnlRight.Controls.Add(ucmd);
            ucmd.Visible = true;

        }

        private void btnHome_Click(object sender, EventArgs e)
        {
            this.pnlRight.Controls.Add(ucmd);
            ucmd.Visible = true;
            ucmp.Visible = false;
            ucmm.Visible=false;
            uccp.Visible=false;
            uccmt.Visible = false;
        }

        private void btnLogout_Click(object sender, EventArgs e)
        {
            FormLogin formLogin = new FormLogin();
            formLogin.Show();
            this.Hide();

        }

        private void btnChangePassword_Click(object sender, EventArgs e)
        {
            this.pnlRight.Controls.Add(uccp);
            ucmd.Visible = false;
            ucmp.Visible = false;
            ucmm.Visible = false;
            uccp.Visible = true;
            uccmt.Visible = false;
        }

        private void btnTransaction_Click(object sender, EventArgs e)
        {
            this.pnlRight.Controls.Add(uccmt);
            ucmd.Visible = false;
            ucmp.Visible = false;
            ucmm.Visible = false;
            uccp.Visible = false;
            uccmt.Visible = true;
        }
    }
}
