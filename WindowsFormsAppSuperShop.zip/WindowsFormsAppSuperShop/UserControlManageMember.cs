﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using WFADBG;

namespace WindowsFormsAppSuperShop
{
    public partial class UserControlManageMember : UserControl
    {
        private DataAccess Da { get; set; }
        public UserControlManageMember()
        {
            InitializeComponent();
            this.Da=new DataAccess();
            this.PopulatedGridView();
        }

        public void PopulatedGridView(string sql = "Select * from Info;")
        {
            var ds = this.Da.ExecuteQuery(sql);
            this.dgvInfo.DataSource = ds.Tables[0];
        }

        private void pnlBackground_Paint(object sender, PaintEventArgs e)
        {

        }

        private void btnAddMember_Click(object sender, EventArgs e)
        {
            FormAddMember fam=new FormAddMember();
            this.Show();
            fam.Show();
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {

            try
            {
                if (this.dgvInfo.SelectedRows.Count < 1)
                {
                    MessageBox.Show("Please select a row first to remove the data", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                    return;
                }

                DialogResult result = MessageBox.Show("Are you sure to remove this Person?", "Alert", MessageBoxButtons.YesNo, MessageBoxIcon.Exclamation);
                if (result == DialogResult.No)
                    return;

                var UserID = this.dgvInfo.CurrentRow.Cells[0].Value.ToString();
                var UserName = this.dgvInfo.CurrentRow.Cells["UserName"].Value.ToString();
                var query = "delete from Info where UserID = '" + UserID + "';";
                var count = this.Da.ExecuteDMLQuery(query);

                if (count == 1)
                    MessageBox.Show(UserName.ToUpper() + " has been removed from the list.");
                else
                    MessageBox.Show("Remove failed");

                this.PopulatedGridView();
              
            }
            catch (Exception exc)
            {
                MessageBox.Show("Error has occured:\n" + exc.Message);
            }
        }


        private void btnRefresh_Click(object sender, EventArgs e)
        {
            this.PopulatedGridView();
        }

        private void txtSearch_TextChanged(object sender, EventArgs e)
        {
            string sql = @"select * from Info where UserID = '" + this.txtSearch.Text + "';";
            this.PopulatedGridView(sql);
        }

        private void lblSearch_Click(object sender, EventArgs e)
        {

        }

        private void lblHeder_Click(object sender, EventArgs e)
        {

        }

        private void dgvInfo_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
          
        }
    }
}
