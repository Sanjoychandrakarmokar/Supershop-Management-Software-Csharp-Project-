﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using WFADBG;

namespace WindowsFormsAppSuperShop
{
    public partial class UserControlManagerTransaction : UserControl
    {
        private DataAccess Da { get; set; }
        public UserControlManagerTransaction()
        {
            InitializeComponent();
            this.Da = new DataAccess();
            this.PopulatedGridView();
        }
        public void PopulatedGridView(string sql = "Select * from money;")
        {
            var ds = this.Da.ExecuteQuery(sql);
            this.dgvTransaction.DataSource = ds.Tables[0];
        }


        private void txtSearch_TextChanged(object sender, EventArgs e)
        {
            string sql = @"select * from money where UserID = '" + this.txtSearch.Text + "';";
            this.PopulatedGridView(sql);
        }

        private void btnRefresh_Click(object sender, EventArgs e)
        {
            this.PopulatedGridView();
        }

        private void pnlBackground_Paint(object sender, PaintEventArgs e)
        {

        }
    }
}
