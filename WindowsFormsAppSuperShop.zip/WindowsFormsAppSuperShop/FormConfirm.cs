﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using WFADBG;

namespace WindowsFormsAppSuperShop
{
    public partial class FormConfirm : Form
    {
        private DataAccess Da { get; set; }

        public FormConfirm()
        {
            InitializeComponent();
            this.Da = new DataAccess();
            this.PopulatedGridView();
        }

       /* public FormConfirm(string text, FormAddCart fad)
        {
            this.txtCustomerID.Text += text;
            this.FAC = fad;
        }
       */
            public void PopulatedGridView(string sql= "Select * from money")
            {
            var ds = this.Da.ExecuteQuery(sql);
            this.dgvfinal.DataSource = ds.Tables[0];
            }

        private void FormConfirm_Load(object sender, EventArgs e)
        {

        }

        private void txtCustomerID_TextChanged(object sender, EventArgs e)
        {
            string sql = @"select * from money where CustomerID = '" + this.txtCustomerID.Text + "';";
            this.PopulatedGridView(sql);
        }
    }
}
