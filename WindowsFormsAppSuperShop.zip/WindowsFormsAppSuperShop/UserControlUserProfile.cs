﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsAppSuperShop
{
    public partial class UserControlUserProfile : UserControl
    {
        private FormUserHome fh { get; set; }
        public UserControlUserProfile()
        {
            InitializeComponent();
        }

        public UserControlUserProfile(string text, FormUserHome fh): this()
        {
            this.txtUserID.Text = text;
            this.fh = fh;
        }


        private void lblID_Click(object sender, EventArgs e)
        {

        }

        private void pnlBackground_Paint(object sender, PaintEventArgs e)
        {

        }
    }
}
