﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using WFADBG;

namespace WindowsFormsAppSuperShop
{
    public partial class FormAddMember : Form
    {
        private DataAccess Da { get; set; }

        public FormAddMember()
        {
            InitializeComponent();
            this.Da = new DataAccess();
            this.PopulatedGridView();
           
        }

        public void PopulatedGridView(string sql = "Select * from Info;")
        {
            var ds = this.Da.ExecuteQuery(sql);
            this.dgvView.DataSource = ds.Tables[0];
        }

        private void FormAddMember_Load(object sender, EventArgs e)
        {

            this.dgvView.ClearSelection();

        }

        private void btnsave_Click(object sender, EventArgs e)
        {
            try
            {

                if (!this.IsValidToSave())
                {
                    MessageBox.Show("Please fill all the information");
                    return;
                }

                string query = null;
                var sql = "select * from Info where UserID='" + this.txtUserID.Text + "';";
                var ds= this.Da.ExecuteQuery(sql);

                if (ds.Tables[0].Rows.Count == 1)
                {
                    query = @"update Info 
                        set UserName = '" +this.txtName.Text + @"',
                        Phone = '" +this.txtPhone.Text + @"',
                        Email = '" +this.txtEmail.Text + @"' ,
                        Address = '" +this.txtAddress.Text + @"',
                        Gender = '" +this.cmbGender.Text + @"',
                        EmployeePosition = '" + this.cmbEmployeePosition.Text + @"',
                        Password = '" + this.txtPassword.Text + @"',
                        UserType = '" + this.cmbType.Text + @"' 
                        where UserID = '" +this.txtUserID.Text + "'";

                    var count = this.Da.ExecuteDMLQuery(query);

                    if(count == 1)
                        MessageBox.Show("Update Sucessful");
                    else
                        MessageBox.Show("Update failed");
                }

                else
                {
                    query = "insert into Info values('"+this.txtUserID.Text+"','"+this.txtName.Text+"','"+this.txtPhone.Text+"','"+this.txtEmail.Text+"','"+this.txtAddress.Text+"','"+this.cmbGender.Text+"','"+this.cmbEmployeePosition.Text+"','"+this.txtPassword.Text+"','"+this.cmbType.Text+"');";
                    var count=this.Da.ExecuteDMLQuery(query);
                    if(count ==1)
                        MessageBox.Show("New Employee Added Sucessful");
                    else
                        MessageBox.Show("Operation failed");

                }

                this.PopulatedGridView();
                this.ClearAll();



            }
            catch
            {
                MessageBox.Show("Error");
            }
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            this.ClearAll();
         

        }

        private void ClearAll()
        {
            this.txtUserID.Clear();
            this.txtName.Clear();
            this.txtPhone.Clear();
            this.txtEmail.Clear();
            this.txtAddress.Clear();
            this.cmbGender.SelectedIndex = -1;
            this.cmbEmployeePosition.SelectedIndex = -1;
            this.txtPassword.Clear();
            this.cmbType.SelectedIndex = -1;

            this.txtSearch.Clear();
            this.dgvView.ClearSelection();
          

        }

        private void txtSearch_TextChanged(object sender, EventArgs e)
        {
            string sql = @"select * from Info where UserID = '" + this.txtSearch.Text + "';";
            this.PopulatedGridView(sql);
        }


        private bool IsValidToSave()
        {
            if (String.IsNullOrEmpty(this.txtUserID.Text) || String.IsNullOrEmpty(this.txtName.Text)
            || String.IsNullOrEmpty(this.txtPhone.Text) || String.IsNullOrEmpty(this.txtEmail.Text)
            || String.IsNullOrEmpty(this.txtAddress.Text)|| String.IsNullOrEmpty(this.cmbGender.Text) || String.IsNullOrEmpty(this.cmbEmployeePosition.Text)
            || String.IsNullOrEmpty(this.txtPassword.Text) || String.IsNullOrEmpty(this.cmbType.Text))
                return false;
            else
                return true;
        }

        

        private void dgvView_DoubleClick(object sender, EventArgs e)
        {
            this.txtUserID.Text = this.dgvView.CurrentRow.Cells[0].Value.ToString();
            this.txtName.Text = this.dgvView.CurrentRow.Cells[1].Value.ToString();
            this.txtPhone.Text = this.dgvView.CurrentRow.Cells[2].Value.ToString();
            this.txtEmail.Text = this.dgvView.CurrentRow.Cells[3].Value.ToString();
            this.txtAddress.Text = this.dgvView.CurrentRow.Cells[4].Value.ToString();
            this.cmbGender.Text = this.dgvView.CurrentRow.Cells[5].Value.ToString();
            this.cmbEmployeePosition.Text = this.dgvView.CurrentRow.Cells[6].Value.ToString();
            this.txtPassword.Text = this.dgvView.CurrentRow.Cells[7].Value.ToString();
            this.cmbType.Text = this.dgvView.CurrentRow.Cells[8].Value.ToString();

        }
    }
}
