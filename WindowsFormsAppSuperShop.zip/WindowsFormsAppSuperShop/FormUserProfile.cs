﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.ListView;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.StartPanel;

namespace WindowsFormsAppSuperShop
{
    public partial class FormUserProfile : Form
    {
        private FormUserHome Fm {  get; set; }

        public FormUserProfile()
        {
            InitializeComponent();
            Display();
        }

        public FormUserProfile(string text, FormUserHome fm): this()
        {
            this.txtUserID.Text = text;
            this.Fm = fm;
        }


        private void Display()
        {
            SqlConnection Con = new SqlConnection(connectionString:@"Data Source=DESKTOP-6CCVGDN\SQLEXPRESS;Initial Catalog=DB;Integrated Security=True;Encrypt=False");
            Con.Open();
            try
            {
                var sqlQuery = $@"select UserName,Phone,Email,Address,Gender,EmployeePosition from Info where UserID = " + this.txtUserID.Text + ";";
                var sql =new SqlCommand(sqlQuery,Con);
                SqlDataReader sdr=sql.ExecuteReader();

                sdr.Read();
                //this.txtUserID.Text = sdr["UserID"].ToString();
                this.txtUserName.Text = sdr["UserName"].ToString();
                this.txtUserPhone.Text = sdr["Phone"].ToString();
                this.txtUserEmail.Text = sdr["Email"].ToString();
                this.txtUserAddress.Text = sdr["Address"].ToString();
                this.txtGender.Text = sdr["Gender"].ToString();
                this.txtUserPosition.Text = sdr["EmployeePosition"].ToString();

            }
            catch
            {
                
            }
            
        }



        private void FormUserProfile_Load(object sender, EventArgs e)
        {
            Display();
        }
    }
}
