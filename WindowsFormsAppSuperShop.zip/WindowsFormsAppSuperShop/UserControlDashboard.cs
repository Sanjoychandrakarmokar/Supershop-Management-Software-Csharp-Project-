﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using WFADBG;

namespace WindowsFormsAppSuperShop
{
    public partial class UserControlDashboard : UserControl
    {
        private DataAccess Da { get; set; }
      
        public UserControlDashboard()
        {
            InitializeComponent();
            this.Da = new DataAccess();
            this.PopulatedGridView();
        }

        public void PopulatedGridView(string sql = "select * from ProductInfo;")
        {
            var ds = this.Da.ExecuteQuery(sql);
            this.dgvItems.DataSource = ds.Tables[0];
        }



        private void btnADD_Click(object sender, EventArgs e)
        {
           

            string query = null;
            var sql = "select * from ProductInfo where ProductID='" + this.txtProductID.Text + "';";
            var ds = this.Da.ExecuteQuery(sql);

            query = @"insert into  sellsInfo values (" + this.txtProductID.Text + ",'" + this.txtProductName.Text + "'," + this.txtProductPrice.Text + "," + this.txtProductQuantity.Text + ",'" + this.txtProductType + "'," + this.txtProductPrice.Text + " * " + this.txtProductQuantity.Text + ","+this.txtUserID.Text+");";
            var count = this.Da.ExecuteDMLQuery(query);

            if (count == 1)
                MessageBox.Show("Add Cart Sucessful");
            else
                MessageBox.Show("Operation failed");


            FormAddCart fac = new FormAddCart();
            this.Visible = true;
            fac.Visible = true;


            this.dgvItems.ClearSelection();
            this.PopulatedGridView();


        }


       

        

      
        private void dgvItems_DoubleClick(object sender, EventArgs e)
        {
            this.txtProductID.Text = this.dgvItems.CurrentRow.Cells[0].Value.ToString();
            this.txtProductName.Text = this.dgvItems.CurrentRow.Cells[1].Value.ToString();
            this.txtProductPrice.Text = this.dgvItems.CurrentRow.Cells[2].Value.ToString();
            this.txtProductType.Text = this.dgvItems.CurrentRow.Cells[3].Value.ToString();
        }

        private void txtSearch_TextChanged(object sender, EventArgs e)
        {
            string sql = @"select * from ProductInfo where ProductID = '" + this.txtSearch.Text + "';";
            this.PopulatedGridView(sql);
        }

        private void btnRefresh_Click(object sender, EventArgs e)
        {
            this.PopulatedGridView();
            this.txtSearch.Clear();
            this.ClearAll();
        }
        private void ClearAll()
        {
            this.txtProductID.Clear();
            this.txtProductName.Clear();
            this.txtProductPrice.Clear();
            this.txtProductQuantity.Clear();
            this.txtProductType.Clear();  
            
            this.txtSearch.Clear();

          
            this.dgvItems.ClearSelection();


        }
        private void pnlHeader_Paint(object sender, PaintEventArgs e)
        {

        }
    }
}
