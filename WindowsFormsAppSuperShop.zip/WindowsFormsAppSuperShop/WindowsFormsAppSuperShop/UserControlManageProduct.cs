﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsAppSuperShop
{
    public partial class UserControlManageProduct : UserControl
    {
        public UserControlManageProduct()
        {
            InitializeComponent();
        }

        private void pnlBackground_Paint(object sender, PaintEventArgs e)
        {

        }

        private void btnAddMember_Click(object sender, EventArgs e)
        {
            FormAddProduct fap  = new FormAddProduct();
            fap.Show();
            this.Show();

        }
    }
}
