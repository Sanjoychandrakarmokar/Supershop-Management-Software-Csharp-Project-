﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsAppSuperShop
{
    public partial class UserControlManageMember : UserControl
    {
        public UserControlManageMember()
        {
            InitializeComponent();
        }

        private void pnlBackground_Paint(object sender, PaintEventArgs e)
        {

        }

        private void btnAddMember_Click(object sender, EventArgs e)
        {
            FormAddMember fam=new FormAddMember();
            this.Show();
            fam.Show();
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {

        }

        private void btnRefresh_Click(object sender, EventArgs e)
        {

        }

        private void txtSearch_TextChanged(object sender, EventArgs e)
        {

        }

        private void lblSearch_Click(object sender, EventArgs e)
        {

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void lblHeder_Click(object sender, EventArgs e)
        {

        }
    }
}
