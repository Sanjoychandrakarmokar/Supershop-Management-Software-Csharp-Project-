﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsAppSuperShop
{
    public partial class FormManagerHome : Form
    {
        UserControlManageMember ucmm=new UserControlManageMember();
        UserControlManageProduct ucmp=new UserControlManageProduct();
        public FormManagerHome()
        {
            InitializeComponent();
        }

        private void pnlLeft_Paint(object sender, PaintEventArgs e)
        {

        }

        private void pnlHome_Click(object sender, EventArgs e)
        {

        }

        private void btnManageMember_Click(object sender, EventArgs e)
        {
            this.pnlRight.Controls.Add(ucmm);
            ucmm.Visible = true;
            ucmp.Visible = false;
        }

        private void FormManagerHome_FormClosed(object sender, FormClosedEventArgs e)
        {
            Application.Exit();
        }

        private void FormManagerHome_Load(object sender, EventArgs e)
        {

        }

        private void btnManageProduct_Click(object sender, EventArgs e)
        {
            this.pnlRight.Controls.Add(ucmp);
            ucmp.Visible = true;
            ucmm.Visible = false;
           
        }
    }
}
