﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsAppSuperShop
{
    public partial class FormUserHome : Form
    {
       
        private FormLogin fl { get; set; }

        UserControlDashboard ucd=new UserControlDashboard();
        //UserControlUserProfile ucp=new UserControlUserProfile();
        UserControlUserChangePassword ucucp=new UserControlUserChangePassword();
        UserControlProductCheck ucpc    =new UserControlProductCheck();

      //  public static FormUserHome instance;
        public FormUserHome()
        {
            InitializeComponent();
           // instance = this;
        }

         public FormUserHome(string text, FormLogin fl):this()
         { 
           this.txtUserID.Text += text;
           this.fl = fl;
            
         }
        

        private void btnDashboard_Click(object sender, EventArgs e)
        {

            
            // UserControlDashboard ucd = new UserControlDashboard();
            this.pnlRight.Controls.Add(ucd);
            //this.Show();
            ucd.Visible = true;
            // ucp.Visible = false;
            ucucp.Visible = false;
             ucpc.Visible = false;
            //this.Hide();
        }

        private void btnProfile_Click(object sender, EventArgs e)
        {
            
            FormUserProfile fum= new FormUserProfile(this.txtUserID.Text,this);
            fum.Visible=true;
            //this.Hide();
           // UserControlUserProfile ucp = new UserControlUserProfile();
           //this.pnlRight.Controls.Add(ucp);
           //this.Show();
           // ucp.Visible = true;
           //this.Hide();
           // ucd.Visible = false;
           // ucucp.Visible = false;
           // ucpc.Visible = false;



        }

        private void btnChangePassword_Click(object sender, EventArgs e)
        {
            //UserControlUserChangePassword ucucp = new UserControlUserChangePassword();
            this.pnlRight.Controls.Add(ucucp);
           // this.Show();
            ucucp.Visible = true;
           // this.Hide();
          // ucp.Visible = false;
            ucd.Visible = false;
           ucpc.Visible = false;

        }

        private void FormUserHome_Load(object sender, EventArgs e)
        {
            //UserControlDashboard ucd = new UserControlDashboard();
            this.pnlRight.Controls.Add(ucd);
           // this.Show();
           ucd.Visible = true;
            //this.Hide();
        }

        private void btnLogout_Click(object sender, EventArgs e)
        {
            FormLogin formLogin = new FormLogin();
            formLogin.Show();
            this.Hide();

        }

        private void FormUserHome_FormClosed(object sender, FormClosedEventArgs e)
        {
            Application.Exit();
        }

        private void btnProductCheck_Click(object sender, EventArgs e)
        {
            //UserControlProductCheck ucpc = new UserControlProductCheck();
            this.pnlRight.Controls.Add(ucpc);
           // this.Show();
            ucpc.Visible = true;
            //this.Hide();
           // ucp.Visible = false;
           ucd.Visible = false;
          ucucp.Visible = false;

        }

        private void pnlRight_Paint(object sender, PaintEventArgs e)
        {

        }

        private void txtUserID_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
