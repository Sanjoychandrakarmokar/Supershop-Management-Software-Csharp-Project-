﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using WFADBG;

namespace WindowsFormsAppSuperShop
{
    public partial class FormAddProduct : Form
    {
       private DataAccess Da { get; set; }
        public FormAddProduct()
        {
            InitializeComponent();
            this.Da = new DataAccess();
            
        }

        private void btnSubmit_Click(object sender, EventArgs e)
        {

            try
            {
                if (!this.IsValidToSave())
                {
                    MessageBox.Show("Please fill all the information");
                    return;
                }
                string query = null;
                var sql = "select * from ProductInfo where ProductID='" + this.txtProductID.Text + "';";
                var ds = this.Da.ExecuteQuery(sql);

                if (ds.Tables[0].Rows.Count == 1)
                {
                    query = @"update ProductInfo
                        set ProductName = '" + this.txtProductName.Text + @"',
                        ProductPrice = '" + this.txtProductPrice.Text + @"' ,
                        ProductType = '" + this.txtType.Text + @"' 
                        where ProductID = '" + this.txtProductID.Text + "'";

                    var count = this.Da.ExecuteDMLQuery(query);

                    if (count == 1)
                        MessageBox.Show("Update Sucessful");
                    else
                        MessageBox.Show("Update failed");
                }

                else
                {
                    query = "insert into ProductInfo values('" + this.txtProductID.Text + "','" + this.txtProductName.Text + "','" + this.txtProductPrice.Text + "','" + this.txtType.Text+"');";
                    var count = this.Da.ExecuteDMLQuery(query);
                    if (count == 1)
                        MessageBox.Show("Product Added Sucessful");
                    else
                        MessageBox.Show("Operation failed");
                }

            }
            catch
            {
                MessageBox.Show("Error");
            }
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            this.ClearAll();
        }

        private void ClearAll()
        {
            this.txtProductID.Clear();
            this.txtProductName.Clear();
            //this.txtProductQuantity.Clear();
            this.txtProductPrice.Clear();
            this.txtType.Clear();
        


        }

        private bool IsValidToSave()
        {
            if (String.IsNullOrEmpty(this.txtProductID.Text) || String.IsNullOrEmpty(this.txtProductName.Text)
            || String.IsNullOrEmpty(this.txtProductPrice.Text)
            || String.IsNullOrEmpty(this.txtType.Text))
                return false;
            else
                return true;
        }

        private void FormAddProduct_Load(object sender, EventArgs e)
        {

        }
    }
}
