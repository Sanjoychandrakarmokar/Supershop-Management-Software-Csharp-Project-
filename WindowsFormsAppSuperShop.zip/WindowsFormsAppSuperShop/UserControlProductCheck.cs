﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using WFADBG;

namespace WindowsFormsAppSuperShop
{
    public partial class UserControlProductCheck : UserControl
    {
        private DataAccess Da { get; set; }
        public UserControlProductCheck()
        {
            InitializeComponent();
            this.Da = new DataAccess();
            this.PopulatedGridView();
        }
        public void PopulatedGridView(string sql = "Select * from ProductInfo;")
        {
            var ds = this.Da.ExecuteQuery(sql);
            this.dgvProductInfo.DataSource = ds.Tables[0];
        }

        private void pnlBackground_Paint(object sender, PaintEventArgs e)
        {

        }

        private void txtSearch_TextChanged(object sender, EventArgs e)
        {
            string sql = @"select * from ProductInfo where ProductName = '" + this.txtSearch.Text + "';";
            this.PopulatedGridView(sql);
        }

        private void btnRefresh_Click(object sender, EventArgs e)
        {
            this.PopulatedGridView();
        }
    }
}
